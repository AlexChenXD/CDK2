prompt Importing table ldcode...
set feedback off
set define off
insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idfiletypelist', 'INS-1163-1', 'INS-1163-1', 'MELI_ANZL', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idfiletypelist', 'INS-1163-2', 'INS-1163-2', 'MELI_ANZL', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idfiletypelist', 'INS-1163-3', 'INS-1163-3', 'MELI_ANZL', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idfiletypelist', 'INS-INSH-6009-1', 'INS-INSH-6009-1', 'INSH', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idfiletypelist', 'INS-INSH-6009-2', 'INS-INSH-6009-2', 'INSH', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idfiletypelist', 'INS-INSH-6009-3', 'INS-INSH-6009-3', 'INSH', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idfiletypelist', 'INS-1163-1-1', 'INS-1163-1-1', 'SC', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idfiletypelist', 'INS-1163-2-1', 'INS-1163-2-1', 'SC', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('idfiletypelist', 'INS-1163-3-1', 'INS-1163-3-1', 'SC', null, null);

prompt Done.
